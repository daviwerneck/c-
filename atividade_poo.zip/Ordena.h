#include <iostream>
class Ordena
{
    public:
        void Bolha(int [], int, int*, int*);
        void BolhaM(int [], int, int*, int*);
        void Insercao(int [], int, int*, int*);
        void Selecao(int[], int, int*, int*);
        void geraVetor(int [], int);
        void copiaVetor(int[], int[], int);
        void exibeVetor(int [], int);


    private:
        int i, j, aux, eleito, menor, pos;
        bool troca;
};
