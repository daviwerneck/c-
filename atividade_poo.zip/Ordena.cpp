#include "Ordena.h"

void Ordena::Bolha(int v[], int t, int *trocas, int *comp){
    for(i = 0; i < t; i++){
        for(j = 0; j < t -1; j++){
            (*comp)++;
            if(v[j] > v[j+1]){
                (*trocas)++;
                aux = v[j];
                v[j] = v[j+1];
                v[j+1] = aux;
            }
        }
    }
};


void Ordena::BolhaM(int v[], int t, int *trocas, int *comp){
    i = 1;
    troca = true;
    while (( i <= t ) && ( troca ) ) {
        troca = false ;
        for ( j = 0; j < t -1; j ++) {
            (*comp)++;
            if ( v [ j ] > v [ j +1]) {
                (*trocas)++;
                troca = true ;
                aux = v [ j ];
                v [ j ] = v [ j +1];
                v [ j +1] = aux ;
            }
        }
        i ++;
    }
}


void Ordena::Insercao(int v[], int t, int *trocas, int *comp){
    for( i = 1; i < t ; i ++) {
        eleito = v [ i ];
        j = i - 1;
        while (( j >= 0) && ( v [ j ] > eleito ) ) {
            v [ j + 1] = v [ j ];
            j --;
            (*comp)++;
            (*trocas)++;
        }
        v [ j + 1] = eleito ;
        (*trocas)++;
    }
};


void Ordena::Selecao(int v[], int t, int *trocas, int *comp){
    for( i = 0; i < t -1; i ++) {
        eleito = v [ i ];
        menor = v [ i + 1];
        pos = i + 1;
        for ( j = i +2; j < t ; j ++) {
            (*comp)++;
            if ( v [ j ] < menor ) {
                menor = v [ j ];
                pos = j ;
            }
        }
        (*comp)++;
        if ( menor < eleito ) {
            (*trocas)++;
            v [ i ] = v [ pos ];
            v [ pos ] = eleito ;
        }
    }
};


void Ordena::geraVetor(int v[], int t){
    for(i = 0; i < t; i++)
        v[i] = rand() % 100 + 1;
};


void Ordena::copiaVetor(int v[], int v2[], int t){
    for(i = 0; i < t; i++)
        v2[i] = v[i];
};


void Ordena::exibeVetor(int v[], int t){
    for(i = 0; i < t; i++)
        std::cout << v[i] << " ";
};
