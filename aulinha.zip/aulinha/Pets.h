#include <iostream>

class Pets{
    private:
        std::string Nome, raca;
        int Tipo, Idade;
        Pets *anterior, *proximo;
    public:
        Pets** Inserir(Pets**, std::string, std::string, int, int);
        Pets** Excluir(Pets**, std::string, int, bool*);
        void Listar(Pets**, int);
        Pets* Pesquisar(Pets**, std::string, int);
        std::string getNome();
        std::string getRaca();
        int getTipo();
        int getIdade();
        }
