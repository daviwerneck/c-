#include "Pets.h"

Pets** Pets::Inserir(Pets **R, std::string n, std::string r, int t, int i){
    Pets *novo = new Pets();
    novo->Nome = n;
    novo->Raca = r;
    novo->Tipo = t;
    novo->Idade = i;
    //inserindo o primeiro
    if R[0] == NULL){
        R[0] = novo;
        R[1] = novo;
        R[0]->anterior = NULL;
        R[1]->proximo = NULL;}
    }else{
        Pets *atual;
        // inserindo um cão
        if(novo->Tipo == 1){
            atual = R[0];
            while((atual != NULL) && (novo->Nome > atual->Nome) && (atual->Tipo == 1)){
                atual = atual->proximo;
            }
        }else{
            //inserindo um gato
            atual = R[1];
            while((atual != NULL) && (novo->Nome < atual->Nome) && (atual->Tipo == 2)){
                atual = atual->proximo;
            }
        }
    }
