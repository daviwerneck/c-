# include <iostream>
# include <unistd.h>

class Lista
{
public:
    std::string Nome;
    int Tempo;
    Lista *elo ;
    Lista** Inserir( Lista**, std::string, int ) ;
    void Percorrer( Lista**) ;
    Lista** Remover( Lista**, std::string) ;
    Lista** Executar( Lista**);
};
