# include "Lista.h"

using namespace std;

int main ()
{
    Lista **P, obj ;
    string N;
    int op, T ;
    P = new Lista *[2];
    P [0] = NULL ;
    P [1] = NULL ;
    do
    {
        system (" clear ") ;
        cout << " ############ MENU ##############\n\n";
        cout << "1 - Inserir Processos\n";
        cout << "2 - Exibir Processos\n";
        cout << "3 - Executar Processos\n";
        cout << "4 - Sair \n";
        cout << " Escolha a opção : ";
        cin >> op ;
        switch ( op )
        {
        case 1:
            cout << " Digite o nome : ";
            cin.ignore() ;
            getline( cin, N );
            cout << " Digite o tempo: ";
            cin >> T;
            P = obj . Inserir(P, N, T);
            cout << " Dados inseridos com sucesso!\n";
            break ;
        case 2:
            if(P [0] == NULL )
            {
                cout << " Sem procesos para listar!\n";
            }
            else
            {
                cout << " ###### Listagem ######\n";
                obj . Percorrer( P);
            }
            break ;
        case 3:
            if(P [0] == NULL )
            {
                cout << " Sem processos para executar!\n ";
            }
            else
            {
                P = obj.Executar(P);
                cout << "Executado com sucesso!";

            }
            break ;
        case 4:
            cout << " Tchau!\ n";
            break ;
        default:
            cout << " Opção inválida!\n ";
        }
        cout << " Tecle Enter para continuar! ";
        cin . ignore () . get () ;
    }
    while( op != 4) ;

    return 0;
}
