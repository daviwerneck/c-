#include "Site.h"

void Site::Listar(Site *I){
    Site *aux = I;
    while(aux != NULL){
        std::cout << aux->URL_do_site << " | " << aux ->Quantidade_de_Acessos << "/n";
        aux = aux->elo;
    }
};

Site** Site::Inserir(Site **R, std::string U, int q){
    Site *novo = new Site();
    novo->URL_do_site = U;
    if(R[0] = NULL){
        R[0] = novo;
        R[1] = novo;
        R[1]->elo = NULL;
        q += 1;
    }else{
        Site *atual = R[0], *ant = NULL;
        while((atual != NULL) && (novo->URL_do_site > atual->URL_do_site)){
            ant = atual;
            atual = atual->elo;
        }
        if(atual == R[0]){
            novo->elo = R[0];
            R[0] = novo;
        }else if(atual == NULL){
            R[1]->elo = novo;
            R[1] = novo;
        }else{
            ant->elo = novo;
            novo->elo = atual;
        }
    }
    return R;
};

Site** Site::Excluir(Site **R, std::string U, bool *achei){
    Site *atual = R[0], *ant = NULL;
    while((atual != NULL) && (atual->URL_do_site != U)){
        ant = atual;
        atual = atual->elo;
    }
    if(atual == NULL){
        *achei = false;
        return R;
    }else{
        *achei = true;
        if(atual == R[0]){
            R[0] = R[0]->elo;
        }else if(atual = R[1]){
            R[1] = ant;
            R[1]->elo = NULL;
        }else{
            ant->elo = atual->elo;
        }
        delete(atual);
    }
    return R;
};



















