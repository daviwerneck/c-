#include <Site.h>

using namespace std;

void Menu(){
    system("clear");
    cout << "1 - Inserir \n";
    cout << "2 - Exluir \n";
    cout << "3 - Listagem Geral \n";
    cout << "4 - Finalizar o Programa \n";
    cout << "Informe sua opção: ";
    }

int main()
{
    Site **P, L;
    P = new Site*[2];
    P[0] = NULL;
    P[1] = NULL;
    string url;
    int op, qtd;
    bool achei;
    do{
        Menu();
        cin >> op;
        switch(op){
            case 1:
                cout << "Informe o URL: ";
                cin.ignore();
                getline(cin, url);
                P = L.Inserir(P, url);
                cout << "Inserido com sucesso!\n";
                break;
            case 2:
                if(P[0] == NULL){
                    cout << "Lista vazia!\n";
                }else{
                    cout << "Informe o site a ser excluído: ";
                    cin.ignore();
                    getline(cin, url);
                    P = L.Excluir(P, url, &achei);
                    if(achei)
                        cout << "Excluído com sucesso!\n";
                    else
                        cout << "Site não localizado!\n";

                }
                break;
            case 3:
                if(P[0] == NULL){
                    cout << "Lista vazia!\n";
                }else{
                    cout << "Lista de Sites\n\n";
                    L.Listar(P[0]);
                }
                break;
            case 4:
                cout << "Tchau!\n";
                break;
            default:
                cout << "Opção inválida!\n";
        }
        cin.ignore().get();
    }while(op != 4);
    return 0;
}
