#include "Site.h"

using namespace std;

void Menu(){
    system("clear");
    cout << "1 - Inserir \n";
    cout << "2 - Exluir \n";
    cout << "3 - Listagem Geral \n";
    cout << "4 - Finalizar o Programa \n";
    cout << "Informe sua opção: ";
    }

int main()
{
    Site **S, *pesq, obj;
    S = new Site*[2];
    S[0] = S[1] = NULL;
    string url;
    int op, acessos;
    bool achou;
    do{
        Menu();
        cin >> op;
        switch(op){
            case 1:
                cout << "Informe o URL: ";
                cin >> url;
                pesq = obj.Pesquisar(S[0], url);
                if(pesq == NULL){
                    S = obj.Inserir(S, url, 1);
                }else{
                    acessos = pesq->Quantidade_de_Acessos + 1;
                    S = obj.Excluir(S, url, &achou);
                    S = obj.Inserir(S, url, acessos);
                }
                cout << "Inserido com sucesso!\n";
                break;
            case 2:
                cout << "Informe o site a ser excluído: ";
                    cin >> url;
                    S = obj.Excluir(S, url, &achou);
                    if(achou)
                        cout << "Excluído com sucesso!\n";
                    else
                        cout << "Site não localizado!\n";
                break;
            case 3:
                if(S[0] == NULL){
                    cout << "Lista vazia!\n";
                }else{
                    cout << "Lista de Sites\n\n";
                    obj.Listar(S[0]);
                }
                break;
            case 4:
                cout << "Tchau!\n";
                break;
            default:
                cout << "Opção inválida!\n";
        }
        cin.ignore().get();
    }while(op != 4);
    return 0;
}
