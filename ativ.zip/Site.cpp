#include "Site.h"

Site** Site::Inserir(Site **R, std::string U, int Q){
    Site *novo = new Site();
    novo->URL_do_site = U;
    novo->Quantidade_de_Acessos = Q;
    if(R[0] == NULL){
        R[0] = novo;
        R[1] = novo;
        R[1]->elo = NULL;
        Q += 1;
    }else{
        Site *atual = R[0], *ant = NULL;
        while(atual != NULL && atual->Quantidade_de_Acessos > novo->Quantidade_de_Acessos){
            ant = atual;
            atual = atual->elo;
        }
        while(atual != NULL && atual->Quantidade_de_Acessos == novo->Quantidade_de_Acessos &&
                atual->URL_do_site < novo->URL_do_site){
            ant = atual;
            atual = atual->elo;
        }
        if(ant == NULL){
            novo->elo = R[0];
            R[0] = novo;
        }else if(atual == NULL){
            R[1]->elo = novo;
            R[1] = novo;
            R[1]->elo = NULL;
        }else{
            ant->elo = novo;
            novo->elo = atual;
        }
    }
    return R;
};

Site** Site::Excluir(Site **R, std::string U, bool *achei){
    Site *atual = R[0], *ant = NULL;
    *achei = false;
    while(atual != NULL && (atual->URL_do_site != U)){
        ant = atual;
        atual = atual->elo;
    }
    if(atual == NULL){
        return R;
    }else{
        if(atual == R[0]){
            R[0] = R[0]->elo;
        }else if(atual == R[1]){
            R[1] = ant;
            R[1]->elo = NULL;
        }else{
            ant->elo = atual->elo;
        }
        delete(atual);
        *achei = true;
    }
    return R;
};

Site* Site::Pesquisar(Site *I, std::string U){
    Site *aux = I;
    while(aux != NULL && aux->URL_do_site != U){
        aux = aux->elo;
    }
    return aux;
};

void Site::Listar(Site *I){
    Site *aux = I;
    while(aux != NULL){
        std::cout << "URL: " << aux->URL_do_site << " | " << aux->Quantidade_de_Acessos << " acesso(s)\n";
        aux = aux->elo;
    }
};















