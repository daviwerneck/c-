#include <iostream>

class Site
{
    public:
        std::string URL_do_site;
        int Quantidade_de_Acessos;
        Site *elo;
        Site** Inserir(Site**, std::string, int);
        Site** Excluir(Site**, std::string, bool*);
        Site* Pesquisar(Site*, std::string);
        void Listar(Site*);
};
