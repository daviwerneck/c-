# include "Arvore.h"

using namespace std;

void Menu ()
{
    system (" clear ");
    cout << " 1. Gerar Árvore \n";
    cout << " 2. Apresentar valores pré-ordem \n";
    cout << " 3. Apresentar valores em ordem \n";
    cout << " 4. Apresentar valores pós-ordem \n";
    cout << " 5. Esvaziar árvore \n";
    cout << " 6. Apresentar somatório de todos os nós \n";
    cout << " 7. Verificar se a soma dos números corresponde a um número perfeito \n";
    cout << " 8. Sair \n";
    cout << " Escolha sua opção : ";
};

int main ()
{
    Arvore * Raiz = NULL, obj ;
    int n, op ;
    bool achou ;
    srand (time(NULL));
    do
    {
        Menu () ;
        cin >> op ;
        switch ( op )
        {
        case 1:
            for(i=0, i<30, i++){
                n = rand() % 100 + 1;
                Raiz = obj . Inserir( Raiz, n );
            }
            break;
        case 2:
            if( Raiz == NULL )
            {
                cout << " Árvore vazia\n";
            }
            else
            {
                cout << " Pré - Ordem\n";
                obj.MostrarPreOrdem(Raiz);
            }
            break ;
        case 3:
            if( Raiz == NULL )
            {
                cout << " Árvore vazia\n";
            }
            else
            {
                cout << " Ordem\n";
                obj.MostrarOrdem(Raiz);
            }
            break ;
        case 4:
            if( Raiz == NULL )
            {
                cout << " Árvore vazia\n";
            }
            else
            {
                cout << " Pós - Ordem\n";
                obj.MostrarPosOrdem(Raiz);
            }
            break ;
        case 5:
            if(Raiz == NULL){
                cout << "Árvore vazia!\n";
            }else{
                Raiz = obj.Esvaziar(Raiz);
            }
            break;
        case 6:

        case 7:

        case 8:
            cout << " Fim !\n";
            break ;
        default:
            cout << " Opção inválida!\n";

        }
        cout << "\nTecle ENTER para continuar.\n";
        cin.ignore().get() ;
    }
    while(op != 8) ;
    return 0;
}
