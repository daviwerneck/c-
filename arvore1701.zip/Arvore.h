# include <iostream>
class Arvore
{
public :
    int Num, AlturaDir, AlturaEsq;
    Arvore *dir, *esq;
    Arvore* Inserir( Arvore*, int) ;
    bool Consultar( Arvore*, int, bool);
    void MostrarPreOrdem ( Arvore*) ;
    void MostrarOrdem ( Arvore*) ;
    void MostrarPosOrdem ( Arvore*) ;

    Arvore* Remover( Arvore*, int) ;
    Arvore* Atualiza( Arvore*) ;
    Arvore* Balanceamento( Arvore*) ;
    Arvore* RotacaoDireita ( Arvore*) ;
    Arvore* RotacaoEsquerda ( Arvore*) ;
};
