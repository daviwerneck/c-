#include "Pets.h"

Pets** Pets::Inserir(Pets **R, std::string n, std::string r, int t, int i){
    Pets *novo = new Pets();
    novo->Nome = n;
    novo->Raca = r;
    novo->Tipo = t;
    novo->Idade = i;
    //inserindo o primeiro
    if (R[0] == NULL){
        R[0] = novo;
        R[1] = novo;
        R[0]->anterior = NULL;
        R[1]->proximo = NULL;
    }else{
        Pets *atual;
        // inserindo um cão
        if(novo->Tipo == 1){
            atual = R[0];
            while((atual != NULL) && (novo->Nome > atual->Nome) && (atual->Tipo == 1)){
                atual = atual->proximo;
            }
        }else{
            //inserindo um gato
            atual = R[1];
            while((atual != NULL) && (novo->Nome < atual->Nome) && (atual->Tipo == 2)){
                atual = atual->anterior;
            }
        }
        if((atual == R[0] && novo->Tipo == 1) || (atual == NULL && novo->Tipo == 2)){
            novo->proximo = R[0];
            R[0]->anterior = novo;
            R[0] = novo;
            R[0]->anterior = NULL;
        }else if((atual == NULL && novo->Tipo == 1) || (atual == R[1] && novo->Tipo == 2)){
            R[1]->proximo = novo;
            novo->anterior = R[1];
            R[1] = novo;
            R[1]->proximo = NULL;
        }else if(novo->Tipo == 1){
            atual->anterior->proximo = novo;
            novo->anterior = atual->anterior;
            novo->proximo = atual;
            atual->anterior = novo;
        }else if(novo->Tipo == 2){
            novo->anterior = atual;
            atual->proximo->anterior = novo;
            novo->proximo = atual->proximo;
            atual->proximo = novo;
        }
    }
    return R;
};
std::string Pets::getNome(){
    return this->Nome;
};
std::string Pets::getRaca(){
    return this->Raca;
};
std::string Pets::getTipo(){
    if(this->Tipo == 1){
        return "Cão";
    }else{
        return "Gato";
    }
};
int Pets::getIdade(){
    return this->Idade;
};
void Pets::Listar(Pets **R, int p){
    Pets *aux;
    bool tem = false;
    //listagem completa
    if(p == 0){
        aux = R[0];
        while(aux != NULL){
            std::cout << "Tipo: " << aux->getTipo() << " - Nome: " << aux->Nome <<
                      " - Raça: " << aux->Raca << " - Idade: " << aux->Idade << " ano(s)\n";
            aux = aux->proximo;
        }
    }else if(p == 1){
        aux = R[0];
        while((aux != NULL) && (aux->Tipo == 1)){
            tem = true;
            std::cout << "Tipo: " << aux->getTipo() << " - Nome: " << aux->Nome <<
                      " - Raça: " << aux->Raca << " - Idade: " << aux->Idade << " ano(s)\n";
            aux = aux->proximo;
        }
        if(!tem){
            std::cout << "Não há cães cadastrados!\n";
        }
    }else{
        aux = R[1];
            while((aux != NULL) && (aux->Tipo == 2)){
                tem = true;
                std::cout << "Tipo: " << aux->getTipo() << " - Nome: " << aux->Nome <<
                      " - Raça: " << aux->Raca << " - Idade: " << aux->Idade << " ano(s)\n";
            aux = aux->anterior;
            }
            if(!tem){
                std::cout << "Não há gatos cadastrados!\n";
            }
    }
};
Pets** Pets::Excluir(Pets **R, std::string n, int t, bool *achei){
    Pets *atual;
    if(t == 1){
        atual = R[0];
        while((atual != NULL) && (atual->Tipo == 1) && (atual->Nome != n)){
            atual = atual->proximo;
        }
    }else{
        atual = R[1];
        while((atual != NULL) && (atual->Tipo == 2) && (atual->Nome != n)){
            atual = atual->anterior;
        }
    }
    if((atual == NULL) || ((atual != NULL) && (atual->Tipo != t))){
        *achei = false;
    }else{
        *achei = true;
        if(atual == R[0]){
            R[0]->anterior = NULL;
            R[0] = R[0]->proximo;
        }else if(atual == R[1]){
            R[1] = R[1]->anterior;
            R[1]->proximo = NULL;
        }else if(t == 1){
            atual->anterior->proximo = atual->proximo;
            atual->proximo->anterior = atual->anterior;
        }else{
            atual->proximo->anterior = atual->anterior;
            atual->anterior->proximo = atual->proximo;
        }
        delete(atual);
    }
    return R;
};
Pets* Pets::Pesquisar(Pets **R, std::string n, int t){
    Pets *aux;
    if(t == 1){
        aux = R[0];
        while((aux != NULL) && (aux->Tipo == 1) && (aux->Nome != n)){
            aux = aux->proximo;
        }
    }else{
        aux = R[1];
        while((aux != NULL) && (aux->Tipo == 2) && (aux->Nome != n)){
            aux = aux->anterior;
        }
    }
    if((aux != NULL) && (aux->Tipo != t)){
        aux = NULL;
    }
    return aux;
};




