#include "Pets.h"

using namespace std;

int main()
{
    Pets **P, obj, *Resp;
    P = new Pets*[2];
    P[0] = NULL;
    P[1] = NULL;
    string nome, raca;
    int tipo, idade, op;
    bool achei;
    do{
        system("clear");
        cout << "1 - Inserir\n";
        cout << "2 - Excluir\n";
        cout << "3 - Listagem completa\n";
        cout << "4 - Listagem cães\n";
        cout << "5 - listagem gatos\n";
        cout << "6 - Pesquisar\n";
        cout << "7 - Sair\n";
        cout << "Informe a opção: ";
        cin >> op;
        switch(op){
            case 1:
                cout << "Informe o nome: ";
                cin.ignore();
                getline(cin, nome);
                cout << "Informe a raça: ";
                getline(cin, raca);
                cout << "Informe: 1 - cães ou 2 - gatos: ";
                cin >> tipo;
                cout << "Informe a idade: ";
                cin >> idade;
                P = obj.Inserir(P, nome, raca, tipo, idade);
                cout << "Inserindo com sucesso!\n";
                break;
            case 2:
                if(P[0] == NULL){
                    cout << "Lista vazia!\n";
                }else{
                    cout << "Informe o nome: ";
                    cin.ignore();
                    getline(cin, nome);
                    cout << "Informe: 1 - cães ou 2 - gatos: ";
                    cin >> tipo;
                    P = obj.Excluir(P, nome, tipo, &achei);
                    if(achei){
                        cout << "Excluído com sucesso!\n";
                    }else{
                        cout << "Registro não encontrado!\n";
                    }
                }
                break;
            case 3:
                if(P[0] == NULL){
                    cout << "Lista vazia!\n";
                }else{
                    cout << "Listagem completa\n";
                    obj.Listar(P, 0);
                }
                break;
            case 4:
                if(P[0] ==NULL){
                    cout << "Lista vazia!\n";
                }else{
                    cout << "Listagem dos cães\n";
                    obj.Listar(P, 1);
                }
                break;
            case 5:
                if(P[0] == NULL){
                    cout << "Lista vazia\n";
                }else{
                    cout << "Listagem dos gatos\n";
                    obj.Listar(P, 2);
                }
                break;
            case 6:
                if(P[0] == NULL){
                    cout << "Lista vazia!\n";
                }else{
                    cout << "Informe o nome: ";
                    cin.ignore();
                    getline(cin, nome);
                    cout << "Informe: 1 - cães ou 2 - gatos: ";
                    cin >> tipo;
                    Resp = obj.Pesquisar(P, nome, tipo);
                    if(Resp == NULL){
                        cout << "Pet não cadastrado\n";
                    }else{
                        cout << Resp->getTipo() << " - " << Resp->getNome() << " - " << Resp->getRaca() <<
                                " - " << Resp->getIdade() << " ano(s)\n";
                    }
                }
                break;
            case 7:
                cout << "Tchau!!!\n";
                break;
            default:
                cout << "Opção inválida...\n";
        }
        cout << "Pressione ENTER para continuar ";
        cin.ignore().get();
    }while(op != 7);
    return 0;
}
