#include "Arvore.h"

Arvore* Arvore::Inserir(Arvore *P, int N){
    Arvore *novo, *aux=P;
    if(aux == NULL){
        novo = new Arvore();
        novo->Num = N;
        novo->AlturaDir = 0;
        novo->AlturaEsq = 0;
        novo->esq = NULL;
        novo->dir = NULL;
        aux = novo;
    }else if(N < aux->Num){
        aux->esq = Inserir(aux->esq, N);
        if(aux->esq->AlturaDir > aux->esq->AlturaEsq)
            aux->AlturaEsq = aux->esq->AlturaDir+1;
        else
            aux->AlturaEsq = aux->esq->AlturaEsq+1;
        aux = Atualiza(aux);
    }else{
        aux->dir = Inserir(aux->dir, N);
        if(aux->dir->AlturaDir > aux->dir->AlturaEsq)
            aux->AlturaDir = aux->dir->AlturaDir+1;
        else
            aux->AlturaDir = aux->dir->AlturaEsq+1;
        aux = Atualiza(aux);
    }
    return aux;
};
void Arvore::MostrarMaior(Arvore *P){
    Arvore *aux = P;
    if(aux != NULL){
        while(aux->dir != NULL){
            aux = aux->dir;
        }
        std::cout << aux->Num;
    }
};
void Arvore::MostrarMenor(Arvore *P){
    Arvore *aux = P;
    if(aux != NULL){
        while(aux->esq != NULL){
            aux = aux->esq;
        }
        std::cout << aux->Num;
    }
};
void Arvore::MostrarPreOrdem(Arvore *P){
    Arvore *aux = P;
    if(aux != NULL){
        std::cout << "|" << aux->AlturaEsq << "| - " << aux->Num << " - |" << aux->AlturaDir << "|" << std::endl;
        MostrarPreOrdem(aux->esq);
        MostrarPreOrdem(aux->dir);
    }
};
Arvore* Arvore::Atualiza(Arvore *P){
    Arvore *aux = P;
    if(aux != NULL){
    aux->esq = Atualiza(aux->esq);
    if(aux->esq == NULL)
        aux->AlturaEsq = 0;
    else if(aux->esq->AlturaEsq > aux->esq->AlturaDir)
        aux->AlturaEsq = aux->esq->AlturaEsq+1;
    else
        aux->AlturaEsq = aux->esq->AlturaDir+1;
    aux->dir = Atualiza(aux->dir);
    if(aux->dir == NULL)
        aux->AlturaDir = 0;
    else if(aux->dir->AlturaEsq > aux->dir->AlturaDir)
        aux->AlturaDir = aux->dir->AlturaEsq+1;
    else
        aux->AlturaDir = aux->dir->AlturaDir+1;
    aux = Balanceamento(aux);
    }
    return aux;
};
Arvore* Arvore::Balanceamento(Arvore *P){
    int d, df;
    Arvore *aux = P;
    d = aux->AlturaDir - aux->AlturaEsq;
    if(d == 2){
        df = aux->dir->AlturaDir - aux->dir->AlturaEsq;
        if(df >= 0)
            aux = RotacaoEsquerda(aux);
        else{
            aux->dir = RotacaoDireita(aux->dir);
            aux = RotacaoEsquerda(aux);
        }
    }else if(d == -2){
        df = aux->esq->AlturaDir - aux->esq->AlturaEsq;
        if(df <= 0)
            aux = RotacaoDireita(aux);
        else{
            aux->esq = RotacaoEsquerda(aux->esq);
            aux = RotacaoDireita(aux);
        }
    }
    return aux;
};
Arvore* Arvore::RotacaoDireita(Arvore *P){
    Arvore *aux = P, *aux1, *aux2;
    aux1 = aux->esq;
    aux2 = aux1->dir;
    aux->esq = aux2;
    aux1->dir = aux;
    if(aux->esq == NULL)
        aux->AlturaEsq = 0;
    else if(aux->esq->AlturaEsq > aux->esq->AlturaDir)
        aux->AlturaEsq = aux->esq->AlturaEsq + 1;
    else
        aux->AlturaEsq = aux->esq->AlturaDir+1;
    if(aux1->dir->AlturaEsq > aux1->dir->AlturaDir)
        aux1->AlturaDir = aux1->dir->AlturaEsq+1;
    else
        aux1->AlturaDir = aux1->dir->AlturaDir+1;
    return aux1;
};
Arvore* Arvore::RotacaoEsquerda(Arvore *P){
    Arvore *aux = P, *aux1, *aux2;
    aux1 = aux->dir;
    aux2 = aux1->esq;
    aux->dir = aux2;
    aux1->esq = aux;
    if(aux->dir == NULL)
        aux->AlturaDir = 0;
    else if(aux->dir->AlturaEsq > aux->dir->AlturaDir)
        aux->AlturaDir = aux->dir->AlturaEsq + 1;
    else
        aux->AlturaDir = aux->dir->AlturaDir + 1;
    if(aux1->esq->AlturaEsq > aux1->esq->AlturaDir)
        aux1->AlturaEsq = aux1->esq->AlturaEsq+1;
    else
        aux1->AlturaEsq = aux1->esq->AlturaDir + 1;
    return aux1;
};
