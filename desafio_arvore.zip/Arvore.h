#include <iostream>
class Arvore
{
    public:
        int Num, AlturaDir, AlturaEsq;
        Arvore  *dir, *esq;
        Arvore* Inserir(Arvore*, int);
        int Consultar(Arvore*, int, int);
        void MostrarPreOrdem(Arvore*);
        void MostrarMaior(Arvore*);
        void MostrarMenor(Arvore*);
        Arvore* Atualiza(Arvore*);
        Arvore* Balanceamento(Arvore*);
        Arvore* RotacaoDireita(Arvore*);
        Arvore* RotacaoEsquerda(Arvore*);
};
