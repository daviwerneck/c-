#include "Arvore.h"

using namespace std;

void Menu(){
    system("clear");
    cout << "1. Gerar Árvore\n";
    cout << "2. Apresentar valores pré-ordem\n";
    cout << "3. Apresentar valores em ordem\n";
    cout << "4. Apresentar valores pós-ordem\n";
}

int main()
{
    srand(time(NULL));
    Arvore *Raiz = NULL, A;
    int numero, k, Soma = 0;

    do{
        numero = rand() % 100 + 1;
        if (numero != 10)
            Raiz = A.Inserir(Raiz, numero);
    }while(numero != 10);

    if(Raiz == NULL)
        cout << "\nÁrvore vazia\n";
    else{
        cout << "\nÁrvore em PRÉ-ORDEM\n\n\n";
        A.MostrarPreOrdem(Raiz);
        cout << "\n\nMaior elemento: ";
        A.MostrarMaior(Raiz);
        cout << "\n\nMenor elemento: ";
        A.MostrarMenor(Raiz);
    }
    return 0;
}
