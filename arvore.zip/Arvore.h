#include <iostream>
class Arvore
{
    public:
        int Num, AlturaDir, AlturaEsq;
        Arvore  *dir, *esq;
        Arvore* Inserir(Arvore*, int);
        int Consultar(Arvore*, int, int);
        void MostrarEmOrdem(Arvore*);
        void MostrarPreOrdem(Arvore*);
        void MostrarPosOrdem(Arvore*);
        Arvore* Esvaziar(Arvore*);
        Arvore* Atualiza(Arvore*);
        Arvore* Balanceamento(Arvore*);
        Arvore* RotacaoDireita(Arvore*);
        Arvore* RotacaoEsquerda(Arvore*);
        void Somar(Arvore*, int*);
        bool Perfeito(int);
};
