#include "Arvore.h"

using namespace std;

#define QUANT 30

void Menu(){
    system("clear");
    cout << "1. Gerar Árvore\n";
    cout << "2. Apresentar valores pré-ordem\n";
    cout << "3. Apresentar valores em ordem\n";
    cout << "4. Apresentar valores pós-ordem\n";
    cout << "5. Esvaziar Árvore\n";
    cout << "6. Apresentar somatório de todos os nós\n";
    cout << "7. Verificar se a soma dos números corresponde à um número perfeito\n";
    cout << "8. Finalizar\n";
    cout << "Escolha: ";
}

int main()
{
    srand(time(NULL));
    Arvore *Raiz = NULL, A;
    int numero, op, k, Soma = 0;
    do{
        Menu();
        cin >> op;
        switch(op){
            case 1:
                if(Raiz != NULL)
                    Raiz = A.Esvaziar(Raiz);
                for(k = 1; k <= QUANT; k++){
                    numero = rand() % 100 + 1;
                    Raiz = A.Inserir(Raiz, numero);
                }
                cout << "\nÁrvore gerada com sucesso!\n";
                break;
            case 2:
                if(Raiz == NULL)
                    cout << "\nÁrvore vazia\n";
                else{
                    cout << "\nÁrvore em PRÉ-ORDEM\n";
                    A.MostrarPreOrdem(Raiz);
                }
                break;
            case 3:
                if(Raiz == NULL)
                    cout << "\nÁrvore vazia\n";
                else{
                    cout << "\nÁrvore EM ORDEM\n";
                    A.MostrarEmOrdem(Raiz);
                }
                break;
            case 4:
                if(Raiz == NULL)
                    cout << "\nÁrvore vazia\n";
                else{
                    cout << "\nÁrvore em PÓS-ORDEM\n";
                    A.MostrarPosOrdem(Raiz);
                }
                break;
            case 5:
                if(Raiz == NULL)
                    cout << "\nÁrvore vazia\n";
                else{
                    Raiz = A.Esvaziar(Raiz);
                    cout << "\nÁrvore removida com sucesso!\n";
                }
                break;
            case 6:
                if(Raiz == NULL)
                    cout << "\nÁrvore vazia\n";
                else{
                    Soma = 0;
                    A.Somar(Raiz, &Soma);
                    cout << "\nSomatório: " << Soma << endl;
                }
                break;
            case 7:
                if(Raiz == NULL)
                    cout << "\nÁrvore vazia\n";
                else{
                    if(Soma == 0)
                        cout << "\nExecute a opção 6!\n";
                    else{
                        if(A.Perfeito(Soma))
                            cout << "\nA Soma é um número perfeito!\n";
                        else
                            cout << "\nA Soma NÃO é um número perfeito!\n";
                    }
                }
                break;
            case 8:
                cout << "\nTchau!!\n";
                break;
            default:
                cout << "\nOpção inválida!\n";
        }
        cout << "Tecle ENTER para continuar: ";
        cin.ignore().get();
    }while(op != 8);
    return 0;
}
